## Django app to create django apps in runtime mode
