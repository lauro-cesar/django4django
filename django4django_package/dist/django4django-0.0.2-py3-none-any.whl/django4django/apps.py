from django.apps import AppConfig


class Django4DjangoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django4django"
